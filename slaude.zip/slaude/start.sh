#!/bin/bash

npm install
node app.js